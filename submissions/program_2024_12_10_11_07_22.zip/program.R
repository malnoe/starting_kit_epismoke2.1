program <-
function(data_train, data_test) {
    ##
    ## YOUR CODE BEGINS HERE
    ## 
    
    # use more represented categorie as model (NULL model)
    status = rev(names(sort(table(data_train$smoking_status))))[1]
    data_pred = rep(status, nrow(data_test))
    
    ##
    ## YOUR CODE ENDS HERE
    ##

    return(data_pred)
    
}
